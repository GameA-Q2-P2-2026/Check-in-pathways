/**
 * Game Design check-ins: receives submissions from the class website and
 * writes them to this spreadsheet. One row per student, per path, per week.
 * If a student submits the same week again, their row is updated, not duplicated.
 *
 * Setup (details are in README.md):
 *   1. Set CLASS_CODE below.
 *   2. Run setup() once and approve the permissions.
 *   3. Deploy > New deployment > Web app.
 *      Execute as: Me.  Who has access: Anyone.
 *   4. Copy the Web app URL into config.js on the website.
 */

var CLASS_CODE = 'CHANGE-ME';   // students type this on the site
var SHEET_NAME = 'Check-ins';
var MAX_LEN = 2000;

var HEADERS = [
  'Updated', 'Name', 'Period', 'Path', 'Week', 'Status', 'Target',
  'Evidence asked for', 'Evidence', 'Finished', 'Doing next', 'Blocked by',
  'Question 1', 'Answer 1', 'Question 2', 'Answer 2', 'Goal for next week',
  'Check-in score (0-4)', 'Path work score (0-6)', 'Teacher notes'
];
var DATA_COLS = 17; // columns A to Q come from the student; R to T are for the teacher

var PATHS = ['design', 'programming', 'development', 'writing'];
var STATUSES = ['green', 'yellow', 'red'];

function setup() {
  var sheet = getSheet_();
  if (sheet.getLastRow() === 0) {
    sheet.appendRow(HEADERS);
    sheet.setFrozenRows(1);
    sheet.getRange(1, 1, 1, HEADERS.length).setFontWeight('bold');
  }
}

function doGet() {
  return json_({ ok: true, message: 'Check-in receiver is running.' });
}

function doPost(e) {
  var lock = LockService.getScriptLock();
  try {
    lock.waitLock(20000);
    var d = JSON.parse(e.postData.contents);

    if (!d.code || String(d.code).trim() !== CLASS_CODE) {
      return json_({ ok: false, error: 'That class code is not correct. Check it with your teacher.' });
    }
    var name = clean_(d.name);
    var path = String(d.path || '');
    var week = parseInt(d.week, 10);
    var status = String(d.status || '');
    if (!name) return json_({ ok: false, error: 'A name is required.' });
    if (PATHS.indexOf(path) === -1 || !(week >= 1 && week <= 5) || STATUSES.indexOf(status) === -1) {
      return json_({ ok: false, error: 'This check-in is missing a path, week, or status.' });
    }

    var row = [
      new Date(), name, clean_(d.period), clean_(d.pathName), week, status,
      clean_(d.target), clean_(d.evidenceAsked), clean_(d.evidence),
      clean_(d.finished), clean_(d.next), clean_(d.blocked),
      clean_(d.question1), clean_(d.answer1), clean_(d.question2), clean_(d.answer2),
      clean_(d.goal)
    ];

    var sheet = getSheet_();
    if (sheet.getLastRow() === 0) setup();
    var values = sheet.getDataRange().getValues();
    var target = -1;
    for (var i = 1; i < values.length; i++) {
      if (String(values[i][1]).toLowerCase() === name.toLowerCase() &&
          String(values[i][3]) === clean_(d.pathName) &&
          Number(values[i][4]) === week) {
        target = i + 1;
        break;
      }
    }
    if (target === -1) {
      sheet.appendRow(row);
    } else {
      sheet.getRange(target, 1, 1, DATA_COLS).setValues([row]);
    }
    return json_({ ok: true });
  } catch (err) {
    return json_({ ok: false, error: 'Something went wrong. Try again, or give your teacher a downloaded copy.' });
  } finally {
    try { lock.releaseLock(); } catch (x) { /* ignore */ }
  }
}

function getSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_NAME) || ss.insertSheet(SHEET_NAME);
}

// Trim, limit length, and stop text that starts like a formula from running as one (a leading space keeps it plain text).
function clean_(value) {
  var text = String(value === undefined || value === null ? '' : value).trim().slice(0, MAX_LEN);
  return /^[=+\-@]/.test(text) ? ' ' + text : text;
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
